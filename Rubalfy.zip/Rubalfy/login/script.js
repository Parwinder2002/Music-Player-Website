const form = document.querySelector('form');
const username = document.getElementById('username');
const password = document.getElementById('password');
const errorMessage = document.getElementById('error-message');

form.addEventListener('submit', function(event) {
    event.preventDefault();
    if (username.value === 'Rubal' || password.value === '2002') {
        window.location.href = "/index.html";
    } else {
        errorMessage.textContent = 'Please enter a valid username and password.';
    }
});