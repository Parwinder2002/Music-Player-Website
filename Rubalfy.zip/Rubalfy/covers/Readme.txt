Download your favourite 10 songs covers, and replace them with these covers, rename them from 1 to 10.
